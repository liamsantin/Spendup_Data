create
    definer = root@localhost procedure sp_mettre_a_jour_progression_objectifs()
BEGIN
    DECLARE done INT DEFAULT 0;
    DECLARE v_objectif_id BIGINT;
    DECLARE v_cible DECIMAL(12,2);
    DECLARE v_total_reel DECIMAL(12,2);

    -- Déclaration du curseur
    DECLARE cur CURSOR FOR
        SELECT id, montant_cible FROM objectifs;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

    OPEN cur;

    read_loop: LOOP
        FETCH cur INTO v_objectif_id, v_cible;
        IF done THEN
            LEAVE read_loop;
        END IF;

        -- Calcule la somme réelle (revenus liés à cet objectif)
        SELECT IFNULL(SUM(t.amount), 0)
        INTO v_total_reel
        FROM transactions t
        INNER JOIN type_transactions tt ON tt.id = t.type_transaction_id
        WHERE t.objectif_id = v_objectif_id
          AND tt.name = 'revenu';

        -- Mise à jour de la progression (évite la division par zéro)
        IF v_cible > 0 THEN
            UPDATE objectifs
            SET progression = ROUND((v_total_reel / v_cible) * 100, 2),
                updated_at = CURRENT_TIMESTAMP
            WHERE id = v_objectif_id;
        END IF;
    END LOOP;

    CLOSE cur;
END;

