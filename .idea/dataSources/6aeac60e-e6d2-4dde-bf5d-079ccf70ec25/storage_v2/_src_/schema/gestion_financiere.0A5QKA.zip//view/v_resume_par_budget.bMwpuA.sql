create definer = root@localhost view v_resume_par_budget as
select `u`.`name`                                                                                              AS `utilisateur`,
       `b`.`name`                                                                                              AS `budget`,
       `b`.`montant_max`                                                                                       AS `montant_prevu`,
       round(sum((case when (`tt`.`name` = 'depense') then `t`.`amount` else 0 end)),
             2)                                                                                                AS `montant_depense`,
       round((`b`.`montant_max` - sum((case when (`tt`.`name` = 'depense') then `t`.`amount` else 0 end))),
             2)                                                                                                AS `montant_restant`,
       round((case
                  when (`b`.`montant_max` > 0) then (
                      (sum((case when (`tt`.`name` = 'depense') then `t`.`amount` else 0 end)) / `b`.`montant_max`) *
                      100)
                  else 0 end),
             2)                                                                                                AS `taux_utilisation`,
       count(`t`.`id`)                                                                                         AS `nb_transactions`,
       `b`.`start_date`                                                                                        AS `start_date`,
       `b`.`end_date`                                                                                          AS `end_date`
from (((`gestion_financiere`.`budgets` `b` join `gestion_financiere`.`users` `u`
        on ((`u`.`id` = `b`.`user_id`))) left join `gestion_financiere`.`transactions` `t`
       on ((`t`.`budget_id` = `b`.`id`))) left join `gestion_financiere`.`type_transactions` `tt`
      on ((`tt`.`id` = `t`.`type_transaction_id`)))
group by `u`.`id`, `u`.`name`, `b`.`id`, `b`.`name`, `b`.`montant_max`, `b`.`start_date`, `b`.`end_date`
order by `taux_utilisation` desc;

