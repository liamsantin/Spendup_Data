create definer = root@localhost trigger before_update_timestamp
    before update
    on users
    for each row
    SET NEW.updated_at = CURRENT_TIMESTAMP;

