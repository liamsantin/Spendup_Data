create definer = root@localhost view v_dashboard_global as
select `u`.`id`                                                                          AS `user_id`,
       `u`.`name`                                                                        AS `user_name`,
       round(sum((case
                      when (`tt`.`name` = 'revenu') then `t`.`amount`
                      when (`tt`.`name` = 'depense') then -(`t`.`amount`)
                      else 0 end)), 2)                                                   AS `balance_globale`,
       round(sum((case when (`tt`.`name` = 'revenu') then `t`.`amount` else 0 end)), 2)  AS `total_revenus`,
       round(sum((case when (`tt`.`name` = 'depense') then `t`.`amount` else 0 end)), 2) AS `total_depenses`,
       count(distinct `a`.`id`)                                                          AS `nb_comptes`,
       count(distinct `b`.`id`)                                                          AS `nb_budgets`,
       count(distinct `o`.`id`)                                                          AS `nb_objectifs`,
       `u`.`created_at`                                                                  AS `created_at`,
       `u`.`updated_at`                                                                  AS `updated_at`
from (((((`gestion_financiere`.`users` `u` left join `gestion_financiere`.`accounts` `a`
          on ((`a`.`user_id` = `u`.`id`))) left join `gestion_financiere`.`transactions` `t`
         on ((`t`.`account_id` = `a`.`id`))) left join `gestion_financiere`.`type_transactions` `tt`
        on ((`tt`.`id` = `t`.`type_transaction_id`))) left join `gestion_financiere`.`budgets` `b`
       on ((`b`.`user_id` = `u`.`id`))) left join `gestion_financiere`.`objectifs` `o` on ((`o`.`user_id` = `u`.`id`)))
group by `u`.`id`, `u`.`name`, `u`.`created_at`, `u`.`updated_at`;

