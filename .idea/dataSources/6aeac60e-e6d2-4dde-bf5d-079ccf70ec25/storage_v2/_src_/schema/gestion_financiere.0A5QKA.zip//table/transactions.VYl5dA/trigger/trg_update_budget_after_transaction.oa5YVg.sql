create definer = root@localhost trigger trg_update_budget_after_transaction
    after insert
    on transactions
    for each row
BEGIN
    DECLARE v_type VARCHAR(50);

    -- Vérifie le type de transaction
    SELECT name INTO v_type
    FROM type_transactions
    WHERE id = NEW.type_transaction_id;

    -- Si c’est une dépense liée à un Budgets, on met à jour le montant dépensé
    IF v_type = 'depense' AND NEW.budget_id IS NOT NULL THEN
        UPDATE budgets
        SET spent_amount = COALESCE(spent_amount, 0) + NEW.amount,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = NEW.budget_id;
    END IF;
END;

