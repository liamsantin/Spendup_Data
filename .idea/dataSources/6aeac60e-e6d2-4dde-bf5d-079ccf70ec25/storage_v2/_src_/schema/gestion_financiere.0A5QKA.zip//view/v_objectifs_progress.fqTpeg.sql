create definer = root@localhost view v_objectifs_progress as
select `o`.`id`                                                                            AS `objectif_id`,
       `u`.`id`                                                                            AS `user_id`,
       `u`.`name`                                                                          AS `user_name`,
       `o`.`name`                                                                          AS `objectif_name`,
       `o`.`montant_cible`                                                                 AS `montant_cible`,
       `o`.`progression`                                                                   AS `progression_declared`,
       coalesce(sum((case when (`tt`.`name` = 'revenu') then `t`.`amount` else 0 end)), 0) AS `montant_economise`,
       round(((coalesce(sum((case when (`tt`.`name` = 'revenu') then `t`.`amount` else 0 end)), 0) /
               `o`.`montant_cible`) * 100), 2)                                             AS `progression_calculee`,
       `s`.`name`                                                                          AS `statut`,
       `o`.`start_date`                                                                    AS `start_date`,
       `o`.`end_date`                                                                      AS `end_date`,
       `o`.`created_at`                                                                    AS `created_at`,
       `o`.`updated_at`                                                                    AS `updated_at`
from ((((`gestion_financiere`.`objectifs` `o` join `gestion_financiere`.`users` `u`
         on ((`u`.`id` = `o`.`user_id`))) join `gestion_financiere`.`statut_objectifs` `s`
        on ((`s`.`id` = `o`.`statut_objectif_id`))) left join `gestion_financiere`.`transactions` `t`
       on ((`t`.`objectif_id` = `o`.`id`))) left join `gestion_financiere`.`type_transactions` `tt`
      on ((`tt`.`id` = `t`.`type_transaction_id`)))
group by `o`.`id`, `u`.`id`, `u`.`name`, `o`.`name`, `o`.`montant_cible`, `o`.`progression`, `s`.`name`,
         `o`.`start_date`, `o`.`end_date`, `o`.`created_at`, `o`.`updated_at`;

