create definer = root@localhost view v_resume_annuel as
select `u`.`name`                                                                        AS `utilisateur`,
       year(`t`.`created_at`)                                                            AS `annee`,
       round(sum((case when (`tt`.`name` = 'revenu') then `t`.`amount` else 0 end)), 2)  AS `total_revenus`,
       round(sum((case when (`tt`.`name` = 'depense') then `t`.`amount` else 0 end)), 2) AS `total_depenses`,
       round(sum((case
                      when (`tt`.`name` = 'revenu') then `t`.`amount`
                      when (`tt`.`name` = 'depense') then -(`t`.`amount`)
                      else 0 end)), 2)                                                   AS `solde_net`,
       count(`t`.`id`)                                                                   AS `nb_transactions`
from (((`gestion_financiere`.`transactions` `t` join `gestion_financiere`.`accounts` `a`
        on ((`a`.`id` = `t`.`account_id`))) join `gestion_financiere`.`users` `u`
       on ((`u`.`id` = `a`.`user_id`))) join `gestion_financiere`.`type_transactions` `tt`
      on ((`tt`.`id` = `t`.`type_transaction_id`)))
group by `u`.`id`, `u`.`name`, year(`t`.`created_at`)
order by `annee` desc;

