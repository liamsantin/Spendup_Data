create definer = root@localhost view v_budget_vs_depenses as
select `b`.`id`                                                                                                   AS `budget_id`,
       `u`.`id`                                                                                                   AS `user_id`,
       `u`.`name`                                                                                                 AS `user_name`,
       `b`.`name`                                                                                                 AS `budget_name`,
       `b`.`montant_max`                                                                                          AS `budget_prevu`,
       coalesce(sum((case when (`tt`.`name` = 'depense') then `t`.`amount` else 0 end)),
                0)                                                                                                AS `depense_reelle`,
       (`b`.`montant_max` - coalesce(sum((case when (`tt`.`name` = 'depense') then `t`.`amount` else 0 end)),
                                     0))                                                                          AS `reste_budget`,
       round(((coalesce(sum((case when (`tt`.`name` = 'depense') then `t`.`amount` else 0 end)), 0) /
               `b`.`montant_max`) * 100),
             2)                                                                                                   AS `pourcentage_utilisation`,
       `b`.`start_date`                                                                                           AS `start_date`,
       `b`.`end_date`                                                                                             AS `end_date`,
       `b`.`created_at`                                                                                           AS `created_at`,
       `b`.`updated_at`                                                                                           AS `updated_at`
from (((`gestion_financiere`.`budgets` `b` join `gestion_financiere`.`users` `u`
        on ((`u`.`id` = `b`.`user_id`))) left join `gestion_financiere`.`transactions` `t`
       on ((`t`.`budget_id` = `b`.`id`))) left join `gestion_financiere`.`type_transactions` `tt`
      on ((`tt`.`id` = `t`.`type_transaction_id`)))
group by `b`.`id`, `u`.`id`, `u`.`name`, `b`.`name`, `b`.`montant_max`, `b`.`start_date`, `b`.`end_date`,
         `b`.`created_at`, `b`.`updated_at`;

