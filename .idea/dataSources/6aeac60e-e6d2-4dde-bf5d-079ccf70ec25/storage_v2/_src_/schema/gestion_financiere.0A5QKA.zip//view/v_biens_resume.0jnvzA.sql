create definer = root@localhost view v_biens_resume as
select `b`.`id`                                               AS `bien_id`,
       `u`.`name`                                             AS `utilisateur`,
       `b`.`nom`                                              AS `nom`,
       `tb`.`nom`                                             AS `type_bien`,
       `b`.`valeur_achat`                                     AS `valeur_achat`,
       `b`.`valeur_actuelle`                                  AS `valeur_actuelle`,
       round((`b`.`valeur_actuelle` - `b`.`valeur_achat`), 2) AS `variation_valeur`,
       `b`.`revenu_annuel`                                    AS `revenu_annuel`,
       `b`.`cout_annuel`                                      AS `cout_annuel`,
       round((`b`.`revenu_annuel` - `b`.`cout_annuel`), 2)    AS `resultat_net_annuel`,
       `b`.`date_acquisition`                                 AS `date_acquisition`,
       `b`.`date_estimation`                                  AS `date_estimation`,
       `b`.`localisation`                                     AS `localisation`,
       `b`.`source_estimation`                                AS `source_estimation`,
       `b`.`created_at`                                       AS `created_at`,
       `b`.`updated_at`                                       AS `updated_at`
from ((`gestion_financiere`.`biens` `b` join `gestion_financiere`.`users` `u`
       on ((`u`.`id` = `b`.`user_id`))) join `gestion_financiere`.`type_biens` `tb`
      on ((`tb`.`id` = `b`.`type_bien_id`)))
order by `b`.`updated_at` desc;

