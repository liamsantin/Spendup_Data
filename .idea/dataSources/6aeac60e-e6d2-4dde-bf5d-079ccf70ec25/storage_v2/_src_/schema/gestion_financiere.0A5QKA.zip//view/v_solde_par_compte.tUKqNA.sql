create definer = root@localhost view v_solde_par_compte as
select `a`.`id`                                            AS `account_id`,
       `u`.`id`                                            AS `user_id`,
       `u`.`name`                                          AS `user_name`,
       `a`.`description`                                   AS `account_name`,
       `a`.`currency_code`                                 AS `currency_code`,
       `a`.`amount`                                        AS `solde_initial`,
       coalesce(sum((case
                         when (`tt`.`name` = 'revenu') then `t`.`amount`
                         when (`tt`.`name` = 'depense') then -(`t`.`amount`)
                         else 0 end)), 0)                  AS `total_transactions`,
       (`a`.`amount` + coalesce(sum((case
                                         when (`tt`.`name` = 'revenu') then `t`.`amount`
                                         when (`tt`.`name` = 'depense') then -(`t`.`amount`)
                                         else 0 end)), 0)) AS `solde_final`,
       `a`.`created_at`                                    AS `created_at`,
       `a`.`updated_at`                                    AS `updated_at`
from (((`gestion_financiere`.`accounts` `a` join `gestion_financiere`.`users` `u`
        on ((`u`.`id` = `a`.`user_id`))) left join `gestion_financiere`.`transactions` `t`
       on ((`t`.`account_id` = `a`.`id`))) left join `gestion_financiere`.`type_transactions` `tt`
      on ((`tt`.`id` = `t`.`type_transaction_id`)))
group by `a`.`id`, `u`.`id`, `u`.`name`, `a`.`description`, `a`.`amount`, `a`.`currency_code`, `a`.`created_at`,
         `a`.`updated_at`;

