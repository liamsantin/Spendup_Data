create definer = root@localhost view v_property_resume as
select `u`.`id`                                                                     AS `user_id`,
       `p`.`id`                                                                     AS `property_id`,
       `p`.`name`                                                                   AS `property_name`,
       `tp`.`name`                                                                  AS `type_bien`,
       `p`.`valeur`                                                                 AS `valeur`,
       `p`.`revenu_annuel`                                                          AS `revenu_annuel`,
       `p`.`cout_annuel`                                                            AS `cout_annuel`,
       (`p`.`revenu_annuel` - `p`.`cout_annuel`)                                    AS `resultat_annuel`,
       round((((`p`.`revenu_annuel` - `p`.`cout_annuel`) / `p`.`valeur`) * 100), 2) AS `rendement_percent`,
       `p`.`date_acquisition`                                                       AS `date_acquisition`,
       `p`.`date_estimation`                                                        AS `date_estimation`
from ((`spendup`.`property` `p` join `spendup`.`user` `u` on ((`u`.`id` = 1))) left join `spendup`.`typeproperty` `tp`
      on ((`tp`.`id` = `p`.`type_property_id`)));

