create definer = root@localhost view v_resume_par_budget as
select `u`.`id`                                                                               AS `user_id`,
       `b`.`id`                                                                               AS `budget_id`,
       `b`.`name`                                                                             AS `budget_name`,
       coalesce(sum((case when (`tt`.`name` = 'Revenu') then `t`.`amount` else 0 end)), 0)    AS `total_revenus`,
       coalesce(sum((case when (`tt`.`name` = 'Dépense') then `t`.`amount` else 0 end)), 0)   AS `total_depenses`,
       (coalesce(sum((case when (`tt`.`name` = 'Revenu') then `t`.`amount` else 0 end)), 0) -
        coalesce(sum((case when (`tt`.`name` = 'Dépense') then `t`.`amount` else 0 end)), 0)) AS `solde_budget`
from (((`spendup`.`budget` `b` join `spendup`.`user` `u`
        on ((`u`.`id` = `b`.`user_id`))) left join `spendup`.`transaction` `t`
       on (((`t`.`budget_id` = `b`.`id`) and (`t`.`user_id` = `b`.`user_id`)))) left join `spendup`.`typetransaction` `tt`
      on ((`tt`.`id` = `t`.`type_transaction_id`)))
group by `u`.`id`, `b`.`id`, `b`.`name`;

