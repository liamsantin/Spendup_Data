create definer = root@localhost view v_objectif_progress as
select `o`.`user_id`                                       AS `user_id`,
       `o`.`id`                                            AS `objectif_id`,
       `o`.`name`                                          AS `objectif_name`,
       `o`.`cible`                                         AS `objectif_cible`,
       `o`.`progression`                                   AS `montant_atteint`,
       round(((`o`.`progression` / `o`.`cible`) * 100), 2) AS `progression_pourcentage`,
       `s`.`name`                                          AS `statut`,
       `o`.`start_date`                                    AS `start_date`,
       `o`.`end_date`                                      AS `end_date`
from (`spendup`.`objectif` `o` left join `spendup`.`statutobjectif` `s` on ((`s`.`id` = `o`.`statut_objectif_id`)));

