create definer = root@localhost view v_resume_annuel as
select `t`.`user_id`                                                                          AS `user_id`,
       year(`t`.`created_at`)                                                                 AS `annee`,
       coalesce(sum((case when (`tt`.`name` = 'Revenu') then `t`.`amount` else 0 end)), 0)    AS `total_revenus`,
       coalesce(sum((case when (`tt`.`name` = 'Dépense') then `t`.`amount` else 0 end)), 0)   AS `total_depenses`,
       (coalesce(sum((case when (`tt`.`name` = 'Revenu') then `t`.`amount` else 0 end)), 0) -
        coalesce(sum((case when (`tt`.`name` = 'Dépense') then `t`.`amount` else 0 end)), 0)) AS `solde_annuel`
from (`spendup`.`transaction` `t` left join `spendup`.`typetransaction` `tt`
      on ((`tt`.`id` = `t`.`type_transaction_id`)))
group by `t`.`user_id`, year(`t`.`created_at`)
order by `annee` desc;

