create definer = root@localhost view v_solde_par_compte as
select `u`.`id`                                                                               AS `user_id`,
       `a`.`id`                                                                               AS `account_id`,
       `a`.`name`                                                                             AS `account_name`,
       `a`.`balance`                                                                          AS `base_balance`,
       coalesce(sum((case when (`tt`.`name` = 'Revenu') then `t`.`amount` else 0 end)), 0)    AS `total_revenus`,
       coalesce(sum((case when (`tt`.`name` = 'Dépense') then `t`.`amount` else 0 end)), 0)   AS `total_depenses`,
       ((`a`.`balance` + coalesce(sum((case when (`tt`.`name` = 'Revenu') then `t`.`amount` else 0 end)), 0)) -
        coalesce(sum((case when (`tt`.`name` = 'Dépense') then `t`.`amount` else 0 end)), 0)) AS `solde_actuel`
from (((`spendup`.`account` `a` join `spendup`.`transaction` `t`
        on ((`t`.`account_id` = `a`.`id`))) join `spendup`.`user` `u`
       on ((`u`.`id` = `t`.`user_id`))) left join `spendup`.`typetransaction` `tt`
      on ((`tt`.`id` = `t`.`type_transaction_id`)))
group by `u`.`id`, `a`.`id`, `a`.`name`, `a`.`balance`;

