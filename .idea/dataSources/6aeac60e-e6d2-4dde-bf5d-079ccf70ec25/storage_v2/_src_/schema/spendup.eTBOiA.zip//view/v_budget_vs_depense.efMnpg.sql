create definer = root@localhost view v_budget_vs_depense as
select `u`.`id`                                                                             AS `user_id`,
       `b`.`id`                                                                             AS `budget_id`,
       `b`.`name`                                                                           AS `budget_name`,
       `b`.`max_amount`                                                                     AS `montant_budget`,
       coalesce(sum((case when (`tt`.`name` = 'Dépense') then `t`.`amount` else 0 end)), 0) AS `total_depense`,
       round(((coalesce(sum((case when (`tt`.`name` = 'Dépense') then `t`.`amount` else 0 end)), 0) /
               `b`.`max_amount`) * 100), 2)                                                 AS `taux_utilisation`
from (((`spendup`.`budget` `b` join `spendup`.`user` `u`
        on ((`u`.`id` = `b`.`user_id`))) left join `spendup`.`transaction` `t`
       on (((`t`.`budget_id` = `b`.`id`) and (`t`.`user_id` = `b`.`user_id`)))) left join `spendup`.`typetransaction` `tt`
      on ((`tt`.`id` = `t`.`type_transaction_id`)))
group by `u`.`id`, `b`.`id`, `b`.`name`, `b`.`max_amount`;

