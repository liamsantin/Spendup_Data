create definer = root@localhost view v_dashboard_global as
select `u`.`id`                                                                                      AS `user_id`,
       (select count(0) from `spendup`.`account`)                                                    AS `nb_comptes`,
       (select count(0) from `spendup`.`budget` where (`spendup`.`budget`.`user_id` = `u`.`id`))     AS `nb_budgets`,
       (select count(0) from `spendup`.`objectif` where (`spendup`.`objectif`.`user_id` = `u`.`id`)) AS `nb_objectifs`,
       (select count(0)
        from `spendup`.`objectif`
        where ((`spendup`.`objectif`.`user_id` = `u`.`id`) and
               (`spendup`.`objectif`.`progression` >= `spendup`.`objectif`.`cible`)))                AS `nb_objectifs_atteints`,
       (select sum(`t`.`amount`)
        from (`spendup`.`transaction` `t` join `spendup`.`typetransaction` `tt`
              on ((`tt`.`id` = `t`.`type_transaction_id`)))
        where ((`tt`.`name` = 'Revenu') and (`t`.`user_id` = `u`.`id`)))                             AS `total_revenus`,
       (select sum(`t`.`amount`)
        from (`spendup`.`transaction` `t` join `spendup`.`typetransaction` `tt`
              on ((`tt`.`id` = `t`.`type_transaction_id`)))
        where ((`tt`.`name` = 'Dépense') and (`t`.`user_id` = `u`.`id`)))                            AS `total_depenses`,
       (select sum(`spendup`.`account`.`balance`)
        from `spendup`.`account`)                                                                    AS `total_solde_comptes`,
       (select sum(`spendup`.`objectif`.`cible`)
        from `spendup`.`objectif`
        where (`spendup`.`objectif`.`user_id` = `u`.`id`))                                           AS `total_objectifs_cibles`,
       (select sum(`spendup`.`objectif`.`progression`)
        from `spendup`.`objectif`
        where (`spendup`.`objectif`.`user_id` = `u`.`id`))                                           AS `total_objectifs_progression`
from `spendup`.`user` `u`;

